import cv2
import numpy as np
import matplotlib.pyplot as plt
import sys

def main():
    if len(sys.argv) != 3:
        print("Usage: python chromakey.py scenicImageFile greenScreenImageFile outputImageFile")
        return
    
    scenic_image_path = sys.argv[1]
    green_screen_image_path = sys.argv[2]
    #output_path = sys.argv[3]
    
    # Load green screen photo and scenic photo
    green_screen_photo = cv2.imread(green_screen_image_path)
    scenic_photo = cv2.imread(scenic_image_path)
    
    # Define green color range (in HSV)
    lower_green = np.array([35, 50, 50])
    upper_green = np.array([85, 255, 255])
    
    # Convert green screen photo to HSV
    green_screen_hsv = cv2.cvtColor(green_screen_photo, cv2.COLOR_BGR2HSV)
    
    # The rest of your code...
    # (Keep the rest of the code unchanged from here)
    # Create a mask for green pixels
    green_mask = cv2.inRange(green_screen_hsv, lower_green, upper_green)

# Invert the mask
    inverse_mask = cv2.bitwise_not(green_mask)

# Extract person from green screen photo
    person_extracted = cv2.bitwise_and(green_screen_photo, green_screen_photo, mask=inverse_mask)

# Create a white background canvas
    white_background = np.ones_like(green_screen_photo) * 255


    img = green_screen_photo.copy()
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    a_channel = lab[:,:,1]
    th = cv2.threshold(a_channel,127,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)[1]
    masked = cv2.bitwise_and(img, img, mask = th)    # contains dark background
    m1 = masked.copy()
    m1[th==0]=(255,255,255) 
    mlab = cv2.cvtColor(masked, cv2.COLOR_BGR2LAB)
    dst = cv2.normalize(mlab[:,:,1], dst=None, alpha=0, beta=255,norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)

    # Set the person on the white background
    #person_on_white = white_background.copy()
    #person_on_white[inverse_mask > 0] = person_extracted[inverse_mask > 0]
    img2 = cv2.cvtColor(mlab, cv2.COLOR_LAB2BGR)
    img[th==0]=(255,255,255)
    threshold_value = 100
    dst_th = cv2.threshold(dst, threshold_value, 255, cv2.THRESH_BINARY_INV)[1]
    mlab2 = mlab.copy()
    mlab[:,:,1][dst_th == 255] = 127
    img2 = cv2.cvtColor(mlab, cv2.COLOR_LAB2BGR)
    img[th==0]=(255,255,255)
    # Define the lower and upper green color thresholds for the second code snippet
    lower_green_second = np.array([35, 50, 50])
    upper_green_second = np.array([85, 255, 255])

    # Convert green screen image to HSV color space for the second code snippet
    hsv_image_second = cv2.cvtColor(green_screen_photo, cv2.COLOR_BGR2HSV)

    # Create a mask for green color range for the second code snippet

    # Convert the image to grayscale
    gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Apply thresholding to create a mask
    _, mask = cv2.threshold(gray_image, 254.99999999999998, 256, cv2.THRESH_BINARY)

    # Perform morphological operations (optional)


    # Invert the mask
    inverted_mask = cv2.bitwise_not(mask)

    # Extract the person from the original image using the inverted mask
    person_extracted = cv2.bitwise_and(img, img, mask=inverted_mask)
    green_mask_second = cv2.inRange(hsv_image_second, lower_green_second, upper_green_second)

    # Invert the mask to get non-green areas for the second code snippet
    #non_green_mask_second = cv2.bitwise_not(green_mask_second)

    # Extract the person from green screen image for the second code snippet
    #person_second = cv2.bitwise_and(img, img, mask=non_green_mask_second)

    # Calculate the aspect ratio of the person for the second code snippet
    person_height, person_width, _ = person_extracted.shape
    person_aspect_ratio = person_width / person_height

    # Resize the scenic photo to match the size of the person
    scenic_resized = cv2.resize(scenic_photo, (person_width, person_height))

    # Create a mask for the person area for the second code snippet
    person_mask = cv2.cvtColor(person_extracted, cv2.COLOR_BGR2GRAY)
    ret, person_mask = cv2.threshold(person_mask, 1, 255, cv2.THRESH_BINARY)

    # Invert the person mask for the second code snippet
    person_mask_inv = cv2.bitwise_not(inverted_mask)

    # Extract the background area from the resized scenic photo for the second code snippet
    background_area = cv2.bitwise_and(scenic_resized, scenic_resized, mask=person_mask_inv)

    # Combine the person and background images for the second code snippet
    final_image = cv2.add(person_extracted, background_area)

    # Combine the images for displaying without gaps
    combined_top = np.hstack((green_screen_photo, img))
    combined_bottom = np.hstack((scenic_resized, final_image))
    combined_image = np.vstack((combined_top, combined_bottom))

    
    # Display the combined image
    plt.imshow(cv2.cvtColor(combined_image, cv2.COLOR_BGR2RGB))
    plt.axis('off')
    plt.show()
    
if __name__ == "__main__":
    main()
