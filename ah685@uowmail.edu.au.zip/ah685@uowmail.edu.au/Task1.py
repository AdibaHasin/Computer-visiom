import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load the image
image_path = "./greenScreen04.jpg"  # Replace with your image path
image = cv2.imread(image_path)

# Convert the image to the desired color space (e.g., HSV)
color_space_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# Split the color space image into its components
component_1, component_2, component_3 = cv2.split(color_space_image)

# Create a figure with subplots
fig, axs = plt.subplots(2, 2, figsize=(10, 8))

# Original color image
axs[0, 0].imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
#axs[0, 0].set_title('Original Color Image')
axs[0, 0].axis('off')

# Component 1 (H) of HSV color space
axs[0, 1].imshow(component_1, cmap='gray')
#axs[0, 1].set_title('Component 1 (H)')
axs[0, 1].axis('off')

# Component 2 (S) of HSV color space
axs[1, 0].imshow(component_2, cmap='gray')
#axs[1, 0].set_title('Component 2 (S)')
axs[1, 0].axis('off')

# Component 3 (B) of HSV color space
axs[1, 1].imshow(component_3, cmap='gray')
#axs[1, 1].set_title('Component 3 (B)')
axs[1, 1].axis('off')

# Adjust layout and display the plot without extra spacing
plt.tight_layout(pad=0)
plt.show()
